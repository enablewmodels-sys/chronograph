# Dart / Flutter SDK

Dart 3.3+, no third-party dependencies. Add a source dependency in your application's `pubspec.yaml`:

```yaml
dependencies:
  chronodb:
    path: /absolute/path/to/chronograph/sdk/dart
```

```dart
import 'dart:io';
import 'package:chronodb/chronodb.dart';

final client = ChronographClient(Platform.environment['CHRONOGRAPH_URL']!,
    Platform.environment['CHRONOGRAPH_TOKEN']!);
try {
  final page = await client.call('as_of', {'t':'9007199254740993','limit':100});
  print(page);
} finally { client.close(); }
```

Native Dart/Flutter only: `dart:io` excludes Flutter Web. Call `close()` to release sockets. Configure `timeout` and `maxResponseBytes` with named constructor arguments. `ApiException` exposes status, code and retryAfter. `ingest` accepts record maps; `checkpoint` returns the response map. Neither physical device acquisition nor quantum runtime execution is performed by this transport.

This is an alpha.3 source package for the Chronograph Community `/v1` API, not a published package-registry release. Read the [SDK guide](../../docs/SDK.md), [platform recipes](../../docs/INTEGRATIONS.md) and [HTTP API reference](../../docs/API.md).

All IDs and microsecond timestamps are decimal strings. `call` exposes JSON operations; `request` handles GET/DELETE and bounded binary responses. No application write retries are performed. Defaults: 30-second timeout, 4 MiB request/response caps. Remote origins require HTTPS; redirects are rejected. Increase the response cap explicitly for larger Arrow/backup downloads (maximum 256 MiB).

Source-available under [PolyForm Perimeter 1.0.0](LICENSE); preserve [NOTICE](NOTICE). Third-party libraries retain their own licenses.


## BCI and binary data

Use your isolated origin or `https://chronodb.co` and a scoped project key.
Managed routes the origin to the key's project; `/p/PROJECT_ID` is not an SDK
constructor URL. Record session `101` first using the [acquisition guide](https://chronodb.co/documentation/BCI).
The following uses the `client` from the connection example above:

```dart
final window = await client.bciWindow('bci_research', '101', 'eeg', '0', '1000000', channels: [0, 1]);
await for (final page in client.pages('bci_records', arguments: {'instance':'bci_research','session':'101'}, maxPages: 200)) {
  print(page);
}
```

`uploadAsset(Uint8List, metadata)` / `readAsset(id)` handle 1 byte–16 MiB of exact binary data.
Chunk lengths, metadata and pagination progress are checked; malformed responses
fail explicitly. Page iteration is incremental with a configurable 1–10,000 page
budget. Stop consuming (or return false from a callback) to stop fetching.

`bci_sessions`, `bci_session`, `bci_records`, `bci_window` and `bci_manifest` are
shared API operations. All model connectors use the same normalized records,
asset helpers and explicit ingest sequence. BrainFlow/LSL device acquisition and
MNE/CSP training run in the Python acquisition service, not in this HTTP client.
